/*
-----------------------------------------------------------------------------
variable length data - structures and defines
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#define vlMAXIMUM       32511   /* system maximum bytes per record */
#define vlMAXOFF        59      /* index header - maxlen field */
#define vlHASHOFF       61      /* index header - hash table */

#if( 0 )        /* this is for hardcoded 1024 index block size */

#if( ISVARIABLE > 1 )
#  define vlHASHVAL     4       /* hash table offset divisor */
#  define vlHASHLEN     249     /* hash table length */
#else
#  define vlHASHVAL     200     /* hash table offset divisor */
#  define vlHASHLEN     5       /* hash table length */
#endif

#if( ISVARIABLE > 2 )
#define vlNODEMAX       993     /* one less max bytes per node */
#define vlDATAOFF       24      /* extra byte for record number */
#else
#define vlNODEMAX       994     /* max bytes per node */
#define vlDATAOFF       23      /* start of data store in rem node */
#endif

#else           /* this allows dynamic index block sizes */

#if( ISVARIABLE > 1 )
#  define vlHASHLEN     ( ( 125 * ( isam->idxlen / 512 ) ) - 1 )
#  define vlHASHVAL     (   2 * ( isam->idxlen / 512 ) )
#else
#  define vlHASHLEN     5       /* hash table length */
#  define vlHASHVAL     ( 100 * ( isam->idxlen / 512 ) )
#endif

#if( ISVARIABLE > 2 )
#define vlNODERES       31      /* reserved bytes per node */
#define vlDATAOFF       24      /* extra byte for record number */
#else
#define vlNODERES       30      /* reserved bytes per node */
#define vlDATAOFF       23      /* start of data store in rem node */
#endif

#define vlNODEMAX       ( isam->idxlen - vlNODERES )

#endif

struct VLremhead                /* remainder node header details */
  {
  us4b  next;                   /* pointer to next in free list */
  us4b  prev;                   /* pointer to prev in free list */

  int free;                     /* space remaining in node */
  int foff;                     /* pointer to free space */

  us4b  cont;                   /* continuation node */
  int   slot;                   /* continuation slot */
  int   more;                   /* continuation flag */

  int   slots;                  /* number of slots allocated */
  unsigned char hash;           /* free list hash group */
  };


struct VLslotptr                /* slot pointer entry */
  {
  int off;                      /* offset in node */
  int len;                      /* length in node */
  };


struct VLvarinfo                /* record trailer */
  {
  int vlen;                     /* length of variable portion */
  int   slot;                   /* slot number in rem node */
  us4b  node;                   /* remainder node number */
  };
