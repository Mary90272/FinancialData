/*
-----------------------------------------------------------------------------
internal module - base application protocol interface
-----------------------------------------------------------------------------
*/

#include <isap_typenames.h>

#include <isap_namespace.h>

#include <isap_callspace.h>

#define isok_arg_n(C,N,T) ( (C)->len > (N) && *(((C)->ord)+(N)) == (T) )
#define isap_arg_n(C,N)   ( (((C)->ary)+(N))->point )

#define isap_get_n(C,N,T) ( isok_arg_n(C,N,T) ? isap_arg_n(C,N) : 0 )
#define isap_set_n(C,N,X) ( (((C)->ary)+(N))->point = (X) )
