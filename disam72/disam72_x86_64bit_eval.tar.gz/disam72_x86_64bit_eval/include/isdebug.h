/*
-----------------------------------------------------------------------------
tracking and debugging utilities - see also base/isdebug.c and read/debug.ref
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#if( ISDEBUG > 0 )

# if( ISDEBUG > 1 )        /* no syslog available */
#  define LOG_EMERG      0 /* system is unusable */
#  define LOG_ALERT      1 /* action must be taken immediately */
#  define LOG_CRIT       2 /* critical conditions */
#  define LOG_ERR        3 /* error conditions */
#  define LOG_WARNING    4 /* warning conditions */
#  define LOG_NOTICE     5 /* normal, but significant, condition */
#  define LOG_INFO       6 /* informational message */
#  define LOG_DEBUG      7 /* debug-level message */
# else
#  include <syslog.h>
# endif

#endif
