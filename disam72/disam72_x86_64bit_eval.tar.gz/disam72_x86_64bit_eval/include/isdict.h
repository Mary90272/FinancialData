/*
-----------------------------------------------------------------------------
data as dictionary mechanism - public header
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


typedef struct  	/* map object */
  {
  char      *tag;	/* field name */
  char      *map;	/* field mapping */
  char      *rem;       /* remarks, other */
  char      *pad;	/* one flag byte, result string, null */
  uint32_t   off;	/* offset in record */
  uint32_t   len;	/* length in record */
  }
  IsMap;

typedef struct		/* dictionary object */
  {
  uint32_t count;	/* item count */
  uint32_t  size;	/* image size */
  char     *data;	/* record image */
  IsMap   **maps;	/* map pointers */
  }
  IsDict;

#if( ISDECLARE )
# define ISD3(s) s
#else
# define ISD3(s) ()
#endif

#if( ISDATAVOID )
# define ISDD void
#else
# define ISDD char
#endif

#if( ISCONSTCHAR )
# define ISCC const char
#else
# define ISCC char
#endif

#if( ISDYNAMIC == 0 || ISDYNAMIC == 3 || ISDYNAMIC == 4 )
# if( defined ISINTERNAL )
#  define ISD1 
# else
#  define ISD1 extern
# endif
# define ISD2
#endif

#if( ISDYNAMIC == 1 )
# if( defined ISINTERNAL )
#  define ISD1
#  define ISD2 __far __pascal __export
# else
#  define ISD1 extern
#  define ISD2 __far __pascal
# endif
#endif

#if( ISDYNAMIC == 2 )
# if( defined ISINTERNAL )
#  define ISD1 __declspec( dllexport )
# else
#  define ISD1 __declspec( dllimport )
# endif
# define ISD2
#endif

#ifdef __cplusplus
extern "C" {
#endif

ISD1 char * ISD2 isddclose ISD3(( char * ));
ISD1 char * ISD2 isddopenr ISD3(( ISCC *store ));
ISD1 char * ISD2 isddopenw ISD3(( ISCC *store ));

ISD1 int ISD2 isdderase ISD3(( ISCC *store, ISCC *key ));
ISD1 int ISD2 isddstore ISD3(( ISCC *store, ISCC *key, ISCC *tag, int off, int len, ISCC *map, ISCC *rem ));

ISD1 IsDict * ISD2 isddmake ISD3(( ISCC *store, ISCC *key, ISCC *fields ));
ISD1 IsDict * ISD2 isddfree ISD3(( IsDict *dict ));

ISD1 int ISD2 isddcopy ISD3(( IsDict *dest, IsDict *copy ));

ISD1 ISDD * ISD2 isddrec ISD3(( IsDict *dict, int size ));
ISD1 int ISD2 isddsize ISD3(( IsDict *dict ));
ISD1 int ISD2 isddcount ISD3(( IsDict *dict ));

ISD1 char * ISD2 isdotag ISD3(( IsDict *dict, int ord ));
ISD1 int ISD2 isddord ISD3(( IsDict *dict, ISCC *tag ));

ISD1 char * ISD2 isdotype ISD3(( IsDict *dict, int ord ));
ISD1 char * ISD2 isddtype ISD3(( IsDict *dict, ISCC *tag ));

ISD1 int ISD2 isdowide ISD3(( IsDict *dict, int ord ));
ISD1 int ISD2 isddwide ISD3(( IsDict *dict, ISCC *tag ));

ISD1 char * ISD2 isdorem ISD3(( IsDict *dict, int ord ));
ISD1 char * ISD2 isddrem ISD3(( IsDict *dict, ISCC *tag ));

ISD1 char * ISD2 isdoget ISD3(( IsDict *dict, int ord ));
ISD1 char * ISD2 isddget ISD3(( IsDict *dict, ISCC *tag ));

ISD1 int ISD2 isdoset ISD3(( IsDict *dict, int ord, ISCC *val ));
ISD1 int ISD2 isddset ISD3(( IsDict *dict, ISCC *tag, ISCC *val ));

ISD1 char * ISD2 isdoexcept ISD3(( IsDict *dict, int ord ));
ISD1 char * ISD2 isddexcept ISD3(( IsDict *dict, char *tag ));

ISD1 int ISD2 isdIndexInfo ISD3(( IsFile * isam, IsDict * kdsc, int idx ));
ISD1 int ISD2 isdIsamInfo ISD3(( IsFile * isam, IsDict * dict ));
ISD1 IsFile * ISD2 isdCluster ISD3(( IsFile * isam, IsDict * kdsc ));
ISD1 int ISD2 isdCopy ISD3(( IsFile * dest, IsFile * source, IsDict * kdsc ));
ISD1 IsFile * ISD2 isdBuild ISD3(( ISCC * name, int dlen, int mlen, IsDict * kdsc, int mode ));
ISD1 int ISD2 isdAddIndex ISD3(( IsFile * isam, IsDict * kdsc ));
ISD1 int ISD2 isdDelIndex ISD3(( IsFile * isam, IsDict * kdsc ));
ISD1 int ISD2 isdWrite ISD3(( IsFile * isam, IsDict * pad ));
ISD1 int ISD2 isdWrLock ISD3(( IsFile * isam, IsDict * pad ));
ISD1 int ISD2 isdWrCurr ISD3(( IsFile * isam, IsDict * pad ));
ISD1 int ISD2 isdRewrite ISD3(( IsFile * isam, IsDict * pad ));
ISD1 int ISD2 isdRewCurr ISD3(( IsFile * isam, IsDict * pad ));
ISD1 int ISD2 isdRewRec ISD3(( IsFile * isam, uint32_t recnum, IsDict * pad ));
ISD1 int ISD2 isdRewNxt ISD3(( IsFile * isam, IsDict * pad ));
ISD1 int ISD2 isdRead ISD3(( IsFile * isam, IsDict * pad, int mode ));
ISD1 int ISD2 isdStart ISD3(( IsFile * isam, IsDict * key, int len, IsDict * pad, int mode ));
ISD1 int ISD2 isdData ISD3(( IsFile * isam, IsDict * pad, uint32_t recnum ));
ISD1 int ISD2 isdCheckVarlen ISD3(( IsFile * isam, IsDict * stats ));

#ifdef __cplusplus
};
#endif

#if( defined ISINTERNAL )
#else
# undef ISD1
# undef ISD2
# undef ISD3
# undef ISDD
#endif

