/*
-----------------------------------------------------------------------------
base library standard includes and declarations
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/* header files -------------------------------------------------- */

#include <stdlib.h>                     /* system headers */

#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <unistd.h>

#define ISINTERNAL 1

#include <isbase.h>                     /* base structures */
#include <istrans.h>			/* transaction processing */
#include "isport.h"                     /* machine specific */
#include "isdebug.h"			/* debug utilities */

#undef ISINTERNAL


/* base library internal prototypes ------------------------------ */

#ifdef __cplusplus
extern "C" {
#endif

/* isadmin.c */
int isAdmOpen ISD3((IsFile *isam));
int isAdmCheck ISD3((IsFile *isam));
int isAdmClose ISD3((IsFile *isam));
int isAdmDupData ISD3((IsFile *isam, us4b recnum, int wait));
IsFile *isAdmVopen ISD3((char *name, int mode));
IsFile *isAdmVclose ISD3((IsFile *isam));
int isAdmTxnFile ISD3((int txnfd, int pid));
int isAdmBldLock ISD3((void));
int isAdmBldRel ISD3((void));

#if( ISAUDIT )
int isAudInit ISD3((IsFile *isam));
int isAudHead ISD3((IsFile *isam, char *code, us4b recnum));
int isAudVLen ISD3((IsFile *isam, int len));
int isAudBody ISD3((IsFile *isam, char *data, int len));
int isAudDone ISD3((IsFile *isam));
#endif

#if( ISTHREADED )
int isAdmDupLock ISD3((IsFile *isam, int mode));
int isAdmDupDrop ISD3((IsFile *isam, int mode));
void isAdmCrit ISD3((IsFile *isam, int mode));
void isAdmSafe ISD3((IsFile *isam, int mode));
void isAdmFail ISD3((IsFile *isam));
#else
# define isAdmDupLock(I,M)
# define isAdmDupDrop(I,M)
# define isAdmCrit(I,M)
# define isAdmSafe(I,M)
# define isAdmFail(I)
#endif

/* iscomp.c */
int isCompKey ISD3((char *dest, char *old, char *new, int flags, int len));
int isCompNext ISD3((IsNode *node, int flags, int klen, int dlen, int off));
int isCompScan ISD3((char *image, char *value, int start, int stop, int flags, int klen, int dlen));

/* isdatio.c */
int isGetData ISD3((IsFile *isam, ISDD *pad, us4b recnum));
int isPutData ISD3((IsFile *isam, ISDD *pad, us4b recnum));
int isDelCheck ISD3((IsFile *isam, us4b recnum));
int isDelData ISD3((IsFile *isam, us4b recnum));

/* isentry.c */
int isEntry ISD3((struct IsamFile *isam, int workmode));
int isDelta ISD3((struct IsamFile *isam));
int isFail ISD3((struct IsamFile *isam, int iserrno, int iserrio, char stat));
void is_fatal ISD3((char *fmt,...));
void isSetStatus ISD3((struct IsamFile *isam, int er, char s1, char s2, char s3, char s4));

/* isfree.c */
us4b isGetFree ISD3((IsFile *isam, int which));
int isPutFree ISD3((IsFile *isam, int which, us4b recnum));
int isFreeClear ISD3((IsFile *isam, int mode));
int isFreeWrite ISD3((IsFile *isam));
int isFreeFree ISD3((IsFile *isam));
int isFreeDrop ISD3((IsFile *isam, int which));
uint32_t is_free_count ISD3((IsFile *isam, int which, int (*call )(char *node )));

/* isgrow.c */
int isTreeInsert ISD3((IsFile *isam, IsPath *path, char *key, us4b recnum, char locate));

/* ishead.c */
int isMakeHead ISD3((IsFile *isam));
int isLoadHead ISD3((IsFile *isam));
int isHeadWrite ISD3((IsFile *isam));
int isHeadKdsc ISD3((IsFile *isam));
#if( ISSCHEMA )
int isHeadSchema ISD3(( IsFile *isam ));
#endif
int isHeadFree ISD3((IsFile *isam, int which, IsFree *list));
uint32_t isTrueLast( IsFile *isam );

/* isidxio.c */
int isRefNode ISD3((IsFile *isam, IsNode *node));
int isUpdNode ISD3((IsFile *isam, IsNode *node));
int isGetNode ISD3((IsFile *isam, char *image, us4b idxrec));
int isPutNode ISD3((IsFile *isam, char *image, us4b idxrec));
int isMarkNode ISD3((IsFile *isam, char *image, int low, int high));

/* isindex.c */
int isLoadIndexes ISD3((IsFile *isam));
int isMakeIndex ISD3((IsFile *isam, struct keydesc *kdsc));
int isDropIndex ISD3((IsFile *isam, int idx));
int isTestIndex ISD3((IsFile *isam, IsKdsc *kdsc));
int isFindIndex ISD3((IsFile *isam, IsKdsc *kdsc));
int isFreeIndex ISD3((IsFile *isam, int idx));

/* isidxdel.c isbuild.c */
int isWipeIdx ISD3((IsFile *isam, int idx));
int isFillIdx ISD3((IsFile *isam, int idx));

/* iskey.c */
int isKeyMake ISD3((IsKdsc *kdsc, char *dest, char *pad));
int isKeyLoad ISD3((IsKdsc *kdsc, char *dest, char *key));
int isKeyCmp ISD3((IsPath *path, char *one, char *two));
int isKeyMatch ISD3((IsPath *path, char *one, char *two));
int isKeyNull ISD3((IsPath *path, char *key));

/* islocate.c */
int isLocate ISD3((IsFile *isam, ISDD *pad, int mode));
int isEdge ISD3((IsFile *isam, IsPath *path, int mode));
int isWalk ISD3((IsFile *isam, IsPath *path, int mode));
int isFind ISD3((IsFile *isam, IsPath *path, char *key, int mode));
us4b isCurrent ISD3((IsFile *isam));

/* islock.c */
int isLockOpen ISD3((IsFile *isam));
int isLockExcl ISD3((IsFile *isam));
int isDropExcl ISD3((IsFile *isam));
int isDropFile ISD3((IsFile *isam));
int isLockRead ISD3((IsFile *isam));
int isLockWrite ISD3((IsFile *isam));
int isDropLock ISD3((IsFile *isam));
int isLocked ISD3((IsFile *isam, us4b recnum));
int isLockTest ISD3((IsFile *isam, us4b recnum));
int isLockData ISD3((IsFile *isam, us4b recnum, int wait));
int isDropData ISD3((IsFile *isam, us4b recnum));
int isLockDall ISD3((IsFile *isam));
int isDropDall ISD3((IsFile *isam));

/* islkinfo.c */
#if( ISLKINFO == 1 )
int isLKplaced ISD3(( IsFile *isam, us4b record ));
int isLKfailed ISD3(( IsFile *isam, us4b record ));
int isLKreleased ISD3(( IsFile *isam, us4b record ));
int isLKrelall ISD3(( IsFile *isam ));
#endif

/* ismif.c */
is2b ld_int ISD3((char *pad));
int st_int ISD3((is2b value, char *pad));
us4b uld_long ISD3((char *pad));
int ust_long ISD3((us4b value, char *pad));
is4b ld_long ISD3((char *pad));
int st_long ISD3((is4b value, char *pad));
is8b ld_int64 ISD3((char *pad));
int st_int64 ISD3((is8b value, char *pad));

/* isnode.c */
IsNode *isMakeNode ISD3((IsFile *isam, IsPath *path));
IsNode *isFreeNode ISD3((IsNode *node));
int isInitInfo ISD3((IsFile *isam, IsNode *node));
int isNodeWalk ISD3((IsPath *path, int mode));
int isNodeMatch ISD3((IsPath *path, char *target));
int isNodeGreat ISD3((IsPath *path, char *target));

/* ispath.c */
int isPathIns ISD3((IsFile *isam, IsPath *path, us4b idxrec));
int isPathSplit ISD3((IsFile *isam, IsPath *path));
int isPathAdd ISD3((IsFile *isam, IsPath *path, us4b idxrec));
int isPathDown ISD3((IsFile *isam, IsPath *path));
int isPathClear ISD3((IsFile *isam, int mode));
int isPathWrite ISD3((IsFile *isam, int idx));
int isPathFree ISD3((IsFile *isam, IsPath *path));

/* isprune.c */
int isTreeDelete ISD3((IsFile *isam, IsPath *path, char *key, us4b rec));

#if( ISSCHEMA )
/* isschema.c */
int isLdSchema ISD3((IsFile *isam, char *path));
int isDpSchema ISD3((IsFile *isam));
int isStSchema ISD3((IsFile *isam, char *loadfile));
int isRmSchema ISD3((IsFile *isam));
#endif

/* issystem.c - hardware abstraction layer */
int isFScreate ISD3((IsFile *isam, int which, char *name));
int isFSopen ISD3((IsFile *isam, int which, char *name));
int isFSread ISD3((IsFile *isam, int which, ISDD *pad, int len, isfo off));
int isFSwrite ISD3((IsFile *isam, int which, ISDD *pad, int len, isfo off));
is4b isFSlast ISD3((IsFile *isam, int which));
isfo isFSsize ISD3((IsFile *isam, int which));
isfo isFStell ISD3((IsFile *isam, int which));
int isFSclose ISD3((IsFile *isam, int which));
int isFSunlink ISD3((IsFile *isam, int which, char *name));
int isFSrename ISD3((IsFile *isam, int which, char *old, char *new));
int isFSlock ISD3((IsFile *isam, int which, isfo off, is4b len, int wait));
int isFSdrop ISD3((IsFile *isam, int which, isfo off, is4b len));
unsigned int isFSgetpid ISD3((IsFile *isam));
unsigned int isFSgetuid ISD3((IsFile *isam));

/* isnetsys.c - network interface layer */
int32_t isIPaddress( char *host );
int isIPsocket( int32_t host, unsigned short port );
int isCloseSocket( int sock );

/* ismemory.c */
void *is_malloc ISD3((int len));
void *is_memclone ISD3((char *ptr, int len));
void *is_realloc ISD3((char *ptr, int old, int new));
void *is_free ISD3((char *ptr));
void is_memset ISD3((char *dest, int val, int len));

/* issquash.c */
int isDsquash ISD3((char *data, char *dest, int datlen));
int isDexpand ISD3((char *dest, unsigned int dmax, char *data ));

/* istrans.c */
int isLGintxn ISD3((IsFile *isam));
int isLGtest ISD3((IsFile *isam));
int isLGbuild ISD3((int code, IsFile *isam, IsKdsc *key));
int isLGerase ISD3((int code, char *name));
int isLGrename ISD3((int code, char *old, char *new));
int isLGfile ISD3((int code, IsFile *isam));
int isLGindex ISD3((int code, IsFile *isam, IsKdsc *key));
int isLGuniq ISD3((int code, IsFile *isam, us4b uniq));
int isLGdata ISD3((int code, IsFile *isam, us4b recnum, char *data));
int isLGupdate ISD3((int code, IsFile *isam, us4b recnum, char *old, char *new));
IsFile *isLGvopen ISD3((char *name, int mode));
/* int isLGvopen ISD3((IsFile **iptr, char *name, int mode)); */
int isLGvclose ISD3((IsFile *isam));

/* isdelete.c */

int isDelFree ISD3((IsFile *isam, us4b recnum));

/* istree.c */
int isTreeFirst ISD3((IsFile *isam, IsPath *path));
int isTreeLast ISD3((IsFile *isam, IsPath *path));
int isTreeCurr ISD3((IsFile *isam, IsPath *path));
int isTreePrev ISD3((IsFile *isam, IsPath *path));
int isTreeNext ISD3((IsFile *isam, IsPath *path));
int isTreeMatch ISD3((IsFile *isam, IsPath *path, char *target));
int isTreeGreat ISD3((IsFile *isam, IsPath *path, char *target));

/* isvarlen.c */
#if( ISVARIABLE )
int isVLinit ISD3((IsFile *isam));
int isVLdone ISD3((IsFile *isam));
int isVLread ISD3((IsFile *isam, char *data));
int isVLwrite ISD3((IsFile *isam, char *data));
int isVLdel ISD3((IsFile *isam));
#endif


#ifdef __cplusplus
};
#endif
