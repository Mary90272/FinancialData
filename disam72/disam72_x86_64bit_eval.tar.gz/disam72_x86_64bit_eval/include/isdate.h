/* 
-----------------------------------------------------------------------------
structure of a date variable
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


struct BDdate
  {
  unsigned char century;	/* 8 bit int range 0 - 255 */
  unsigned char year;		/* 8 bit int range 0 - 99 */
  unsigned char month;		/* 8 bit int range 1 - 12 */
  unsigned char day;		/* 8 bit int range 1 - 31 */
  };


#define DATESIZE	sizeof( struct BDdate )
#define NULLDATE	{ 0, 0, 0, 0 }
#define ISNODATE( D )	( D.century + D.year + D.month + D.day == 0 )
#define DATECMP( A, B )	( memcmp( A, B, DATESIZE ) )


typedef struct BDdate Date;


struct BDtime
  {
  unsigned char hour;		/* 8 bit int range 0 - 23 */
  unsigned char minute;		/* 8 bit int range 0 - 59 */
  unsigned char second;		/* 8 bit int range 0 - 59 */
  };

#define TIMESIZE	sizeof( struct BDtime )
#define NULLTIME        { 0, 0, 0 }

typedef struct BDtime Time;
