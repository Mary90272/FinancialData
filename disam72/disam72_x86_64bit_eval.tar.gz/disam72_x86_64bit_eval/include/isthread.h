/*
-----------------------------------------------------------------------------
multi-thread handling

this feature owes it's existance to Callum Gibson in australia because
without his expertise and advice it would never have been completed.
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#if( ISTHREADED == 0 )              /* not threaded */
#define ISMTINIT(I) ;;
#define ISMTBEG(I)  ;;
#define ISMTEND(I)  ;;
#define ISMTDROP(I) ;;
# if( ISBITFLAGS & 256 )
# define ISMTWAIT(I1,I2) break;
# define ISMTSIG(I)  ;;
# endif
#endif


#if( ISTHREADED == 1 )              /* SunOS */
#include <lwp/lwp.h>
#define ISMTLOCK     mon_t
#define ISMTINIT(MX) mon_create( MX )
#define ISMTBEG(MX)  mon_enter( MX )
#define ISMTEND(MX)  mon_exit( MX )
#define ISMTDROP(MX) mon_destroy( MX )
# if( ISBITFLAGS & 256 )
# define ISMTWAIT(I1,I2) break;
# define ISMTSIG(I)      break;
# endif
#endif


#if( ISTHREADED == 2 )              /* Solaris */
#include <synch.h>
#define ISMTLOCK     mutex_t
#define ISMTCOND     cond_t
#define ISMTINIT(MX) mutex_init( MX, USYNC_THREAD, NULL )
#define ISMTBEG(MX)  mutex_lock( MX )
#define ISMTEND(MX)  mutex_unlock( MX )
#define ISMTDROP(MX) mutex_destroy( MX )
# if( ISBITFLAGS & 256 )
# define ISMTWAIT(C, MX) cond_wait( C, MX )
# define ISMTSIG(C)      cond_signal( C )
# endif
#endif


#if( ( ISBITFLAGS & 256 ) && ( ISTHREADED == 3 ) )              /* Windows 95 and NT */
#include <windows.h>
struct DCRIT {
    CRITICAL_SECTION cs;
    int cntr;
};
#define ISMTLOCK     struct DCRIT
#define ISMTINIT(MX) { \
                         InitializeCriticalSection( (MX).cs ); \
                         *(MX).cntr = 0; \
                     }
#define ISMTBEG(MX)  { \
                         EnterCriticalSection( (MX).cs ); \
                         *(MX).cntr++; \
                     }
#define ISMTEND(MX)  { \
                         EnterCriticalSection( (MX).cs ); \
                         if( *(MX).cntr > 0 ) { \
                             LeaveCriticalSection( (MX).cs ); \
                             *(MX).cntr--; \
                         } \
                         LeaveCriticalSection( (MX).cs ); \
                     }
#define ISMTDROP(MX) DeleteCriticalSection( (MX).cs )
#endif


#if( ( ( ISBITFLAGS & 256 ) == 0 ) && ( ISTHREADED == 3 ) )              /* Windows */
#include <windows.h>
#define ISMTLOCK     CRITICAL_SECTION
#define ISMTINIT(MX) InitializeCriticalSection( MX )
#define ISMTBEG(MX)  EnterCriticalSection( MX )
#define ISMTEND(MX)  LeaveCriticalSection( MX )
#define ISMTDROP(MX) DeleteCriticalSection( MX )
#endif


#if( ISTHREADED == 4 )              /* OS/2 - unstable */
#define INCL_DOSPROCESS
#include <os2.h>
#undef INCL_DOSPROCESS
#include <stddef.h>
#define ISMTINIT(X)  ;;
#define ISMTBEG(X)   DosEnterCritSec()
#define ISMTEND(X)   DosExitCritSec()
#define ISMTDROP(X)  ;;
#endif    


#if( ISTHREADED == 5 )              /* pthreads */
#include <pthread.h>
#define ISMTLOCK     pthread_mutex_t
#define ISMTCOND     pthread_cond_t
#ifdef _INCLUDE_HPUX_SOURCE
# define ISMTINIT(MX) pthread_mutex_init( MX, pthread_mutexattr_default )
#else
# define ISMTINIT(MX) pthread_mutex_init( MX, NULL )
#endif
#define ISMTBEG(MX)  pthread_mutex_lock( MX )
#define ISMTEND(MX)  pthread_mutex_unlock( MX )
#define ISMTDROP(MX) pthread_mutex_destroy( MX )
#define ISMTWAIT(C, MX)  pthread_cond_wait( C, MX )
#define ISMTSIG(C)   pthread_cond_signal( C )
#define ISCDINIT(C)  pthread_cond_init( C, NULL )
#define ISCDDROP(C)  pthread_cond_destroy( C )
#endif

#if( ISTHREADED == 6 )              /* debugging pthreads */
#include <pthread.h>
#define ISMTLOCK     pthread_mutex_t
#define ISMTCOND     pthread_cond_t
#define ISMTINIT(MX) { pthread_mutex_init( MX, NULL ); isDebug( NULL, -1, "mutex=%x.%x %d:%s", pthread_self(), MX, __LINE__, __FILE__ ); }
#define ISMTBEG(MX)  {                                 isDebug( NULL, -1, "mutex?%x.%x %d:%s", pthread_self(), MX, __LINE__, __FILE__ ); \
                       pthread_mutex_lock( MX );       isDebug( NULL, -1, "mutex+%x.%x %d:%s", pthread_self(), MX, __LINE__, __FILE__ ); }
#define ISMTEND(MX)  { pthread_mutex_unlock( MX );     isDebug( NULL, -1, "mutex-%x.%x %d:%s", pthread_self(), MX, __LINE__, __FILE__ ); }
#define ISMTDROP(MX) { pthread_mutex_destroy( MX );    isDebug( NULL, -1, "mutex!%x.%x %d:%s", pthread_self(), MX, __LINE__, __FILE__ ); }
#endif

