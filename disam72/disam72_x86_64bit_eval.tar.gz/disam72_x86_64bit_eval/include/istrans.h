/*
-----------------------------------------------------------------------------
transaction processing module - structures and configuration
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/* transaction log file codes */

#define LC_BEGIN        16983   /* BW */
#define LC_COMMIT       17239   /* CW */
#define LC_ROLLBACK     21079   /* RW */
#define LC_BUILD        16981   /* BU */
#define LC_ERASE        17746   /* ER */
#define LC_RENAME       21061   /* RE */
#define LC_OPEN         17999   /* FO */
#define LC_CLOSE        17987   /* FC */
#define LC_ADDIDX       17225   /* CI */
#define LC_DELIDX       17481   /* DI */
#define LC_SETUNIQ      21333   /* SU */
#define LC_UNIQUE       21838   /* UN */
#define LC_DELETE       17477   /* DE */
#define LC_INSERT       18766   /* IN */
#define LC_UPDATE       21840   /* UP */
#define LC_CL           17228   /* CL */

/* log file record structures ------------------------------------ */

struct TxnHead
  {
  char len[2];                  /* log record length */
  char code[2];                 /* transaction type code */
#if( ISLONGID > 1 )
  char pid[4];                  /* process identification number */
  char uid[8];                  /* user indentification number */
#elif( ISLONGID > 0 )
  char pid[4];                  /* process identification number */
  char uid[4];                  /* user indentification number */
#else
  char pid[2];                  /* process identification number */
  char uid[2];                  /* user indentification number */
#endif
  char time[4];                 /* transaction time */
  char prev[4];                 /* previous record offset - v2 */
  char plen[2];                 /* previous record length - v2 */
  };

struct TxnBuild                 /* isbuild */
  {
  char mode[2];                 /* build mode */
  char reclen[2];               /* record length */
  char maxlen[2];               /* maximum length - v2 */
  char kflags[2];               /* key flags */
  char nparts[2];               /* key part count */
  char klen[2];                 /* key length */
  };

struct TxnRename                /* isrename */
  {
  char olen[2];                 /* old name length */
  char nlen[2];                 /* new name length */
  };

struct TxnFile                  /* isopen and isclose */
  {
  char file[2];                 /* file number */
  char flag[2];                 /* varlen flag - v2 */
  };

struct TxnIndex                 /* addindex and delindex */
  {
  char file[2];                 /* file number */
  char kflags[2];               /* key flags */
  char nparts[2];               /* key part count */
  char klen[2];                 /* key length */
  };

struct TxnUniq                  /* issetunique, isuniqueid */
  {
  char file[2];                 /* file number */
  char id[4];                   /* new unique id */
  };

struct TxnData                  /* iswrite */
  {                             /* isdelete, isdelcurr and isdelrec */
  char file[2];                 /* file number */
  char recnum[4];               /* record number */
  char reclen[2];               /* record length - v2 */
  };

struct TxnUpdate                /* isrewrite, isrewrec and isrewcurr */
  {
  char file[2];                 /* file number */
  char recnum[4];               /* record number */
  char beflen[2];               /* original record length */
  char aftlen[2];               /* updated record length - v2 */
  };

union TxnRecord
  {
  struct TxnBuild       txbuild;
  struct TxnRename      txrename;
  struct TxnFile        txfile;
  struct TxnIndex       txindex;
  struct TxnUniq        txuniq;
  struct TxnData        txdata;
  struct TxnUpdate      txupdate;
  };
