/*
-----------------------------------------------------------------------------
bytestream packing and unpacking - header file
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#define ISBYTESBLK 1400   /* this will change */

typedef struct { int now; int len; char pad[ISBYTESBLK]; } IsBytes;

int isTxBytes( int fd, char swab, IsBytes *bytes );

IsBytes *isRxBytes( int fd, char swab );

IsBytes *isBstream( IsBytes *bytes, void *blob, int len );

IsBytes *isBstComp( IsBytes *bytes, void *blob, int len );

IsBytes *isBstCode( IsBytes *bytes, char code );

int isBstRead( IsBytes *bytes, void *blob, int max );

void *isBstMake( IsBytes *bytes, void *blob, int max, int old );

int isBstTell( IsBytes *bytes );
int isBstSeek( IsBytes *bytes, int off );
