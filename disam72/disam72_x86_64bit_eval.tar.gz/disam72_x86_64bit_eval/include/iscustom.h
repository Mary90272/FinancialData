/*
-----------------------------------------------------------------------------
custom extensions
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#define ISCUSTKEYS  1           /* 1: custom keys added */

#define QUADTYPE    8
#define QUADSIZE    8

#define BYTETYPE    9
#define BYTESIZE    1

#define RFATYPE     10
#define RFASIZE     6

#define COLLTYPE    11
#define COLLSIZE    1

