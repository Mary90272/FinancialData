/*
-----------------------------------------------------------------------------
standard interface - wrapper library internal header
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


#include <string.h>
#include <sys/types.h>

#include <isbase.h>
#include <isdebug.h>

#define ISINTERNAL 1

#include <iswrap.h>

/* useful definitions -------------------------------------------- */

#define SUCCESS      0
#define DISAM_ERROR -1
#define ISLOCAL	     0
#define ISREMOTE     1

/* the global variables ------------------------------------------ */

#if( defined STDGLOBALS )

#if( ISCISAM > 0 )
 ISD1 long ISD2 isrecnum = 0;
#else
 ISD1 uint32_t ISD2 isrecnum = 0;
#endif
 ISD1 int ISD2 isreclen = 0;
 ISD1 int ISD2 iserrno = 0;
 ISD1 int ISD2 iserrio = 0;
 ISD1 int32_t ISD2 ispid = 0;
#if( ISCOBOL & ISCOBOL_STATS )
 ISD1 char ISD2 isstat1 = 0;
 ISD1 char ISD2 isstat2 = 0;
 ISD1 char ISD2 isstat3 = 0;
 ISD1 char ISD2 isstat4 = 0;
#endif
 

#endif 


/* wrapper handling prototypes ----------------------------------- */

#ifdef __cplusplus
extern "C" {
#endif

#if( ISDECLARE )
# define ISD3(s) s
#else
# define ISD3(s) ()
#endif

#if( ISDATAVOID )
# define ISDT void
#else
# define ISDT char
#endif

int isWrapFind ISD3((IsFile *isam));
IsFile *isWrapInit ISD3((int isfd));
int isWrapDone ISD3((IsFile *isam, int ok));
int isWrapRet ISD3((int ok));
int isWrapTxn ISD3((int ok));


#undef ISD3

#ifdef __cplusplus
};
#endif
