/*
-----------------------------------------------------------------------------
machine/target porting options
-----------------------------------------------------------------------------
*/

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                                         *
 *             Worldwide Copyright (c) Byte Designs Ltd (2022)             *
 *          Version 7.2 (build 2022/12/21) (expire cobol shared)           *
 *                                                                         *
 *                            Byte Designs Ltd.                            *
 *                            20568 - 32 Avenue                            *
 *                               LANGLEY, BC                               *
 *                             V2Z 2C8 CANADA                              *
 *                                                                         *
 *                       Sales: sales@bytedesigns.com                      *
 *                     Support: support@bytedesigns.com                    *
 *              Phone: (604) 534 0722     Fax: (604) 534 2601              *
 *                                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */


/* standard integers - see read/stdint.ref ------------------------------- */

#if( ISHUGE > 0 )
typedef int64_t         isfo;           /* huge file offset */
#else
typedef off_t           isfo;           /* any file offset */
#endif

#if( 1 ) /* these are in use */

typedef	 int16_t 	is2b;		/* is two bytes */
typedef	uint16_t 	us2b;		/* is two bytes */
typedef	 int32_t 	is4b;		/* is four bytes */
typedef	uint32_t 	us4b;		/* is four bytes */
typedef	 int64_t 	is8b;		/* is eight bytes */
typedef	uint64_t 	us8b;		/* is eight bytes */

#else    /* the full set in reserve */

/* exact sizes */
typedef	 int8_t	 	is1b;		/* is one byte */
typedef	 int16_t 	is2b;		/* is two bytes */
typedef	 int32_t 	is4b;		/* is four bytes */
typedef	 int64_t 	is8b;		/* is eight bytes */

/* exact unsigned */
typedef	uint8_t	 	us1b;		/* is one byte */
typedef	uint16_t 	us2b;		/* is two bytes */
typedef	uint32_t 	us4b;		/* is four bytes */
typedef	uint64_t 	us8b;		/* is eight bytes */

/* fastest sizes - as in best fit machine registers */
typedef	 int_fast8_t	is1r;		/* is one byte */
typedef	 int_fast16_t 	is2r;		/* is two bytes */
typedef	 int_fast32_t 	is4r;		/* is four bytes */
typedef	 int_fast64_t 	is8r;		/* is eight bytes */

/* unsigned registers */
typedef	uint_fast8_t	us1r;		/* is one byte */
typedef	uint_fast16_t 	us2r;		/* is two bytes */
typedef	uint_fast32_t 	us4r;		/* is four bytes */
typedef	uint_fast64_t 	us8r;		/* is eight bytes */

typedef intptr_t        ismo;           /* any memory offset */
typedef size_t          isso;           /* largest blob size */

#endif	/* reserved set of standard integer names */

/* IO multiplexing ------------------------------------------------------- */

#define is_create  isFScreate	
#define is_open    isFSopen    
#define is_read    isFSread	
#define is_write   isFSwrite	
#define is_last    isFSlast	
#define is_size    isFSsize	
#define is_tell    isFStell	
#define is_close   isFSclose	
#define is_unlink  isFSunlink	
#define is_rename  isFSrename	
#define is_lock    isFSlock    
#define is_drop    isFSdrop	
#define is_getpid  isFSgetpid	
#define is_getuid  isFSgetuid	

/* locking offsets ------------------------------------------------------- */

#if( ISLOCKING == 1 )                         /* old style table locks */
# define ISLKFILEOFF   (isfo)(0x40000000)     /* offset of file claim table */
# define ISLKBUSYOFF   (isfo)(0x3FF00000)     /* offset of I/O lock table */
# define ISLKBUSYLEN   (isfo)(0x100000)       /* lengths of the above */
# define ISLKDATAOFF   (isfo)(0x40000000)     /* offset of data lock table */
# define ISLKDATALEN   (isfo)(0xFFFFFFF)      /* length of the above */
#endif

#if( ISLOCKING == 2 )                         /* new style read/write */
# if( C7LOCKING == 1 || C7LOCKING == 2 )
#   define ISLKFILEOFF (isfo)(0x7FFFFFFF)     /* offset of file claim table */
# else
#   define ISLKFILEOFF (isfo)(0x40000000)     /* offset of file claim table */
# endif
# define ISLKBUSYOFF   (isfo)(0x0L)           /* offset of I/O lock table */
# define ISLKBUSYLEN   (isfo)(0x3FFFFFFF)     /* lengths of the above */
# define ISLKDATAOFF   (isfo)(0x40000000)     /* offset of data lock table */
# define ISLKDATALEN   (isfo)(0x3FFFFFFF)     /* length of the above */
#endif

#if( ISLOCKING == 3 )                         /* third file method */
# define ISLKFILEOFF   (isfo)(0x00000000)     /* offset of file claim table */
# define ISLKBUSYOFF   (isfo)(0x20000000)     /* offset of I/O lock table */
# define ISLKBUSYLEN   (isfo)(0x20000000)     /* lengths of the above */
# define ISLKDATAOFF   (isfo)(0x40000000)     /* offset of data lock table */
# define ISLKDATALEN   (isfo)(0x40000000)     /* length of the the above */
#endif

/* locking configuration ------------------------------------------------- */

#ifdef _WIN32
# include <sys/locking.h>
# define ISLKCALL         _locking        /* dos locking call */
# define ISLKSET          LK_LOCK         /* wait for and set lock */
# define ISLKTRY          LK_NBLCK        /* attempt lock or fail */
# define ISUNLCK          LK_UNLCK        /* release lock */
#else
# if( ISLOCKING == 1 || ISLOCKING == 3 )
#  if( ISHUGE > 0 )
#   define ISLKCALL        lockf64        /* unix locking call */
#  else
#   define ISLKCALL        lockf          /* unix locking call */
#  endif
#  define ISLKSET         F_LOCK          /* wait for and set lock */
#  define ISLKTRY         F_TLOCK         /* attempt lock or fail */
#  define ISUNLCK         F_ULOCK         /* release lock */
# endif
#endif

/* network IO ------------------------------------------------------------ */

#define isIOread        read
#define isIOwrite       write

/* file support ---------------------------------------------------------- */

#ifdef _WIN32
# if( ISHUGE > 0 )  /* forced handling of 64 bit files in 32 bit */
#  define _is_lseek    _lseeki64
# else              /* assume the compiler has it sorted out */
#  define _is_lseek    _lseek
# endif
#  define _is_open     _open
#  define read         _read
#  define write        _write
#else
# if( ISHUGE > 0 )  /* forced handling of 64 bit files in 32 bit */
#  define _is_lseek    lseek64
#  define _is_open     open64
#  define _is_pread    pread64
#  define _is_pwrite   pwrite64
# else              /* assume the compiler has it sorted out */
#  define _is_lseek    lseek
#  define _is_open     open
#  define _is_pread    pread
#  define _is_pwrite   pwrite
# endif
#endif

/* memory handling ------------------------------------------------------- */

#if( ISBERKELY )
# define ISMEMMOVE(D,S,L)   bcopy(S,D,L)
# define ISMEMCOPY(D,S,L)   bcopy(S,D,L)
# define ISMEMCMP(D,S,L)    bcmp(S,D,L)
# define ISMEMSET(D,V,L)    is_memset((char*)D,V,L)	/* very slow */
#else
# define ISMEMMOVE(D,S,L)   memmove(D,S,L)
# define ISMEMCOPY(D,S,L)   memcpy(D,S,L)
# define ISMEMCMP(D,S,L)    memcmp(D,S,L)
# define ISMEMSET(D,V,L)    memset(D,V,L)
#endif

/* auto repair handling -------------------------------------------------- */

#if( ISREPAIR )
#define reppath		    "/tmp/isamrep"     /* where to put temps */
#endif
