/* test program that illustrates basic isam functionality */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iswrap.h>

#define SUCCESS 0

int main( int argc, char **argv )
  {
  int     fd;
  int     i;
  int	mode;
  char    setchar;
  char	filename[50];

  struct  Record 
   {
   char key1[10];
   char key2[10];
   char buf[100];
   } rec;

  struct keydesc kinfo;

        strcpy( filename, "testfile");

        /* remove .dat and .idx if they already exist */
        iserase( filename );


        /* define primary key */
        kinfo.k_flags = ISDUPS;       /* allow duplicate keys     */
        kinfo.k_nparts = 1;           /* only one key to this key */
        kinfo.k_part[0].kp_start = 0; /* key starts at offset 0   */
        kinfo.k_part[0].kp_leng = 10; /* goes for a length of 10  */
        kinfo.k_part[0].kp_type = CHARTYPE; /* key type is char   */

        fd = isbuild( filename, sizeof( rec ), &kinfo, ISINOUT+ISEXCLLOCK );
        if ( fd < 0 )
         {
         printf("isbuild iserrno = %d\n", iserrno );
         exit(1);
         }

        /* now add a secondary key */
        kinfo.k_flags = ISDUPS;
        kinfo.k_nparts = 1;
        kinfo.k_part[0].kp_start = 10;
        kinfo.k_part[0].kp_leng = 10;
        kinfo.k_part[0].kp_type = CHARTYPE;

        if( isaddindex( fd, &kinfo ) != 0 )
          {
          printf("isaddindex iserrno = %d\n", iserrno );
          isclose(fd);
          exit(1);
          } 
        isclose( fd );

        fd = isopen( filename, ISINOUT + ISMANULOCK );
        if( fd < 0 )
          {
          printf("isopen iserrno = %d\n", iserrno );
          exit(1);
          }

        setchar = 'A';
        for( i=0; i<1000; i++ )
          {
          memset( (char *)&rec, setchar, sizeof( rec ) );
          sprintf( rec.key1, "%c%08ld", setchar, i );
          sprintf( rec.key2, "%08ld%c", i, setchar );
          if( iswrite( fd, (char *)&rec ) != 0 )
            {
            printf( "iswrite iserrno = %d, record: %10s\n", iserrno, rec.key1 );
            isclose( fd );
            exit(1);
            }
          if( setchar == 'Z' ) setchar = 'A';
          else setchar++;
          }

        mode = ISFIRST;
        memset( (char *)&rec, 0, sizeof( rec ) );
        while( isread( fd, (char *)&rec, mode ) == 0 )
          { 
          printf("Rec[%ld]: %10s\n", isrecnum, rec.key1 );
          mode = ISNEXT;
          }
  
        isclose( fd );
  }
